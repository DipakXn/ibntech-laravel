SMTP configuration test

{{ $testBody }}
