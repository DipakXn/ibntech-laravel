<?php

return [

    'breadcrumb' => 'Loetelu',

];
