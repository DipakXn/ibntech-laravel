<?php

return [

    'label' => 'Záložky',

];
