<?php

return [

    'label' => 'Breadcrumb',

];
