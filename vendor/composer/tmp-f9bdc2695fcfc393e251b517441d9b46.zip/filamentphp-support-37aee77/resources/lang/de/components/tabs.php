<?php

return [

    'label' => 'Registerkarten',

];
