<?php

return [

    'label' => 'Cargando...',

];
