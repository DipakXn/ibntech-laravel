<?php

namespace Filament\Support\View;

use Filament\Support\Contracts\LoadingIndicator;
use Illuminate\View\ComponentAttributeBag;

class DefaultLoadingIndicator implements LoadingIndicator
{
    public function toHtml(ComponentAttributeBag $attributes): string
    {
        // The spinner is decorative — the surrounding control (button `aria-label`, loading section
        // `role="status"`) conveys the loading state — so hide it from assistive tech by default. A
        // caller can still override by passing its own `aria-hidden`.
        $attributes = $attributes->merge(['aria-hidden' => 'true'], escape: false);

        return <<<HTML
            <svg
                fill="none"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
                {$attributes->toHtml()}
            >
                <path
                    clip-rule="evenodd"
                    d="M12 19C15.866 19 19 15.866 19 12C19 8.13401 15.866 5 12 5C8.13401 5 5 8.13401 5 12C5 15.866 8.13401 19 12 19ZM12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"
                    fill-rule="evenodd"
                    fill="currentColor"
                    opacity="0.2"
                ></path>
                <path
                    d="M2 12C2 6.47715 6.47715 2 12 2V5C8.13401 5 5 8.13401 5 12H2Z"
                    fill="currentColor"
                ></path>
            </svg>
        HTML;
    }
}
